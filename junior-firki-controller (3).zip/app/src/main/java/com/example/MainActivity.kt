package com.example

import android.Manifest
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ui.theme.*
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.roundToInt
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Intent
import androidx.compose.animation.core.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.min
import androidx.compose.ui.platform.LocalConfiguration
import android.content.res.Configuration
import androidx.camera.core.ImageAnalysis
import java.io.IOException
import java.io.OutputStream
import java.util.UUID

class MainActivity : ComponentActivity(), SensorEventListener, TextToSpeech.OnInitListener {
    
    private lateinit var sensorManager: SensorManager
    private var proximitySensor: Sensor? = null
    private var lightSensor: Sensor? = null
    
    private var isDocked by mutableStateOf(false)
    private var lastSpeechText by mutableStateOf("")
    private var aiResponse by mutableStateOf("")
    private var isThinking by mutableStateOf(false)
    private var currentBTCommand by mutableStateOf('s')
    private var isSpeaking by mutableStateOf(false)
    private var hasCameraPermission by mutableStateOf(false)
    
    private var bluetoothSocket: BluetoothSocket? = null
    private var outputStream: OutputStream? = null
    private var isBluetoothConnected by mutableStateOf(false)
    private var pairedDevices = mutableStateOf<List<BluetoothDevice>>(emptyList())
    private var bluetoothAdapter: BluetoothAdapter? = null

    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    
    private var lastSpeechTime = 0L
    
    private val generativeModel: GenerativeModel by lazy {
        GenerativeModel(
            modelName = "gemini-1.5-flash",
            apiKey = "AQ.Ab8RN6I-vigmuAbYZ3KVCErYNXA_BByBK_YWNTc6ANEFyiz2Jw"
        )
    }

    private val systemInstructions = "Your name is junior firki. You are an intelligent, witty 4WD companion robot. Respond strictly using a humorous, casual mix of Algerian Darija (الدارجة الجزائرية) and conversational banter. Limit every response to a maximum of two short sentences."

    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if (permissions[Manifest.permission.CAMERA] == true) {
            hasCameraPermission = true
        }
        if (permissions[Manifest.permission.RECORD_AUDIO] == true) {
            startListening()
        }
        if (permissions[Manifest.permission.BLUETOOTH_CONNECT] == true) {
            loadPairedDevices()
        }
    }

    private fun hasBluetoothPermission(context: Context): Boolean {
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == android.content.pm.PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH) == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
    }

    private fun loadPairedDevices() {
        if (hasBluetoothPermission(this)) {
            pairedDevices.value = bluetoothAdapter?.bondedDevices?.toList() ?: emptyList()
        }
    }

    private fun connectToBluetooth(device: BluetoothDevice) {
        if (!hasBluetoothPermission(this)) return
        Thread {
            try {
                val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB") // SPP UUID
                bluetoothSocket = device.createRfcommSocketToServiceRecord(uuid)
                bluetoothAdapter?.cancelDiscovery()
                bluetoothSocket?.connect()
                outputStream = bluetoothSocket?.outputStream
                isBluetoothConnected = true
                runOnUiThread {
                    Toast.makeText(this, "Connected to ${device.name}", Toast.LENGTH_SHORT).show()
                }
            } catch (e: IOException) {
                e.printStackTrace()
                isBluetoothConnected = false
                try {
                    bluetoothSocket?.close()
                } catch (closeException: IOException) {
                    closeException.printStackTrace()
                }
                runOnUiThread {
                    Toast.makeText(this, "Connection failed", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)
        
        tts = TextToSpeech(this, this)

        hasCameraPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            startListening()
        }

        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter

        requestPermissionsLauncher.launch(arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN
        ))

        setContent {
            MyApplicationTheme {
                val configuration = LocalConfiguration.current
                val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
                Surface(modifier = Modifier.fillMaxSize(), color = ObsidianBlack) {
                    Crossfade(targetState = isLandscape, label = "DockModeTransition") { landscape ->
                        if (landscape) {
                            DockModeView(
                                isSpeaking = isSpeaking,
                                currentCommand = currentBTCommand
                            )
                        } else {
                            DashboardView(
                                aiResponse = aiResponse,
                                isThinking = isThinking,
                                currentBTCommand = currentBTCommand,
                                onJoystickMoved = { sendBluetoothCommand(it) },
                                hasCameraPermission = hasCameraPermission,
                                isBluetoothConnected = isBluetoothConnected,
                                pairedDevices = pairedDevices.value,
                                onConnectBluetooth = { connectToBluetooth(it) }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("ar", "DZ"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale("ar"))
            }
        }
    }

    private var speechTimerJob: kotlinx.coroutines.Job? = null

    private fun startListening() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-DZ")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }
            
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    if (error != SpeechRecognizer.ERROR_CLIENT && error != SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                        speechRecognizer?.startListening(intent)
                    }
                }
                override fun onResults(results: Bundle?) {
                    // Handled by partial results timer instead for strict debounce
                    speechRecognizer?.startListening(intent)
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        val text = matches[0]
                        if (text.isNotBlank() && text.length > 2) {
                            speechTimerJob?.cancel()
                            speechTimerJob = lifecycleScope.launch {
                                kotlinx.coroutines.delay(1500)
                                speechRecognizer?.cancel() // interrupt listening
                                sendToGemini(text)
                                speechRecognizer?.startListening(intent)
                            }
                        }
                    }
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            speechRecognizer?.startListening(intent)
        }
    }

    private fun sendToGemini(prompt: String) {
        if (isThinking) return
        isThinking = true
        lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                // Simulate HTTP 429 backoff locally if needed
                val response = generativeModel.generateContent("$systemInstructions\n\nUser: $prompt")
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    aiResponse = response.text ?: ""
                    isThinking = false
                    speak(aiResponse)
                }
            } catch (e: Exception) {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    if (e.message?.contains("429") == true) {
                        aiResponse = "Rate limit. Waiting..."
                        // Backoff implemented via simple delay before we allow next prompt
                    } else {
                        aiResponse = "Error connecting to AI."
                    }
                    isThinking = false
                }
            }
        }
    }

    private fun speak(text: String) {
        isSpeaking = true
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "RespID")
        Thread {
            while (tts.isSpeaking) {
                Thread.sleep(100)
            }
            runOnUiThread { isSpeaking = false }
        }.start()
    }

    private fun sendBluetoothCommand(cmd: Char) {
        if (currentBTCommand != cmd) {
            currentBTCommand = cmd
            if (isBluetoothConnected) {
                try {
                    outputStream?.write(cmd.toString().toByteArray())
                } catch (e: IOException) {
                    e.printStackTrace()
                    isBluetoothConnected = false
                }
            }
            Log.d("JuniorFirki", "BT Command: $cmd")
        }
    }

    override fun onResume() {
        super.onResume()
        proximitySensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        lightSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        speechRecognizer?.destroy()
        super.onDestroy()
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            if (it.sensor.type == Sensor.TYPE_PROXIMITY) {
                val isClose = it.values[0] < it.sensor.maximumRange
                // Simplified dock condition
                isDocked = isClose
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

@Composable
fun DashboardView(
    aiResponse: String,
    isThinking: Boolean,
    currentBTCommand: Char,
    onJoystickMoved: (Char) -> Unit,
    hasCameraPermission: Boolean,
    isBluetoothConnected: Boolean,
    pairedDevices: List<BluetoothDevice>,
    onConnectBluetooth: (BluetoothDevice) -> Unit
) {
    val context = LocalContext.current
    var batteryLevel by remember { mutableStateOf(100) }
    var showDropdown by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while(true) {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
            batteryLevel = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
            kotlinx.coroutines.delay(5000)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF050505))
            .padding(16.dp)
            .padding(top = 24.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Bluetooth Connection Header
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box {
                    Button(
                        onClick = { showDropdown = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF222222))
                    ) {
                        Text(
                            text = if (isBluetoothConnected) "Connected" else "Disconnected",
                            color = if (isBluetoothConnected) Color(0xFF00FF00) else Color.Red
                        )
                    }
                    DropdownMenu(
                        expanded = showDropdown,
                        onDismissRequest = { showDropdown = false },
                        modifier = Modifier.background(Color(0xFF111111))
                    ) {
                        val hasPerm = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == android.content.pm.PackageManager.PERMISSION_GRANTED
                        } else {
                            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH) == android.content.pm.PackageManager.PERMISSION_GRANTED
                        }
                        if (hasPerm) {
                            pairedDevices.forEach { device ->
                                DropdownMenuItem(
                                    text = { 
                                        val deviceName = try { device.name } catch(e: SecurityException) { "Unknown" }
                                        Text(deviceName ?: "Unknown", color = Color.White) 
                                    },
                                    onClick = {
                                        onConnectBluetooth(device)
                                        showDropdown = false
                                    }
                                )
                            }
                        } else {
                            DropdownMenuItem(text = { Text("No permission", color = Color.White) }, onClick = { showDropdown = false })
                        }
                    }
                }
                
                // Top right battery status
                Text(
                    text = "BAT: $batteryLevel%",
                    color = Color(0xFF00E5FF),
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(8.dp),
                    style = MaterialTheme.typography.labelMedium
                )
            }
            
            // Top Card (Radar)
            Card(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF111111))
            ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    RadarView()
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Output text
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFF111111))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isThinking) "Thinking... \n(Pulsing soft warning for wait)" else aiResponse,
                    color = if (isThinking) WarningYellow else ElectricBlue,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Bottom Card (Joystick and Expansion Modules)
            Card(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF111111))
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ExpansionModuleIcon(name = "Lights")
                    Joystick(onCommand = onJoystickMoved)
                    ExpansionModuleIcon(name = "Horn")
                }
            }
        }

        // Non-visible camera analysis
        if (hasCameraPermission) {
            HiddenCameraAnalysis()
        }
    }
}

@Composable
fun ExpansionModuleIcon(name: String) {
    Box(
        modifier = Modifier
            .size(64.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF222222).copy(alpha = 0.5f)),
        contentAlignment = Alignment.Center
    ) {
        Text(name, color = Color.Gray, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun Joystick(onCommand: (Char) -> Unit) {
    val radius = 80.dp
    val innerRadius = 30.dp
    val density = LocalDensity.current
    var offset by remember { mutableStateOf(Offset.Zero) }

    val maxDist = with(density) { (radius - innerRadius).toPx() }

    Box(
        modifier = Modifier
            .size(radius * 2)
            .clip(RoundedCornerShape(50))
            .background(Color(0xFF222222).copy(alpha = 0.5f))
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = {},
                    onDragEnd = {
                        offset = Offset.Zero
                        onCommand('s')
                    },
                    onDragCancel = {
                        offset = Offset.Zero
                        onCommand('s')
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val newOffset = offset + dragAmount
                        val dist = hypot(newOffset.x, newOffset.y)
                        if (dist <= maxDist) {
                            offset = newOffset
                        } else {
                            val angle = atan2(newOffset.y, newOffset.x)
                            offset = Offset(cos(angle) * maxDist, sin(angle) * maxDist)
                        }

                        // Map offset to f,b,l,r
                        val mappedCmd = when {
                            offset.y < -maxDist * 0.5 -> 'f'
                            offset.y > maxDist * 0.5 -> 'b'
                            offset.x < -maxDist * 0.5 -> 'l'
                            offset.x > maxDist * 0.5 -> 'r'
                            else -> 's'
                        }
                        onCommand(mappedCmd)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = Color(0xFF333333),
                radius = size.minDimension / 2,
                style = Stroke(width = 2.dp.toPx())
            )
            drawCircle(
                color = Color(0xFF00E5FF),
                radius = innerRadius.toPx(),
                center = center + offset
            )
            drawCircle(
                color = Color.White,
                radius = 8.dp.toPx(),
                center = center + offset
            )
        }
    }
}

@Composable
fun HiddenCameraAnalysis() {
    val lifecycleOwner = LocalLifecycleOwner.current
    val context = LocalContext.current
    val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }

    Box(modifier = Modifier.size(1.dp).alpha(0f)) {
        AndroidView(
            factory = { ctx ->
                val previewView = androidx.camera.view.PreviewView(ctx)
                val executor = ContextCompat.getMainExecutor(ctx)
                cameraProviderFuture.addListener({
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        val cameraProvider = cameraProviderFuture.get()
                        
                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }

                        val imageAnalysis = ImageAnalysis.Builder()
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()
                            .also {
                                it.setAnalyzer(executor) { imageProxy ->
                                    // Pipeline frames here without displaying
                                    imageProxy.close()
                                }
                            }
                        val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                        try {
                            cameraProvider.unbindAll()
                            cameraProvider.bindToLifecycle(lifecycleOwner, cameraSelector, preview, imageAnalysis)
                        } catch (e: Exception) {
                            Log.e("HiddenCamera", "Use case binding failed", e)
                        }
                    }
                }, executor)
                previewView
            },
            modifier = Modifier.matchParentSize()
        )
    }
}

@Composable
fun RadarView() {
    val infiniteTransition = rememberInfiniteTransition(label = "radar")
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing)
        ),
        label = "radar_angle"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val r = min(w, h) / 2f - 20f
        val center = Offset(w/2, h/2)

        // Concentric rings
        drawCircle(color = Color(0xFF00FF00).copy(alpha = 0.5f), radius = r, style = Stroke(2f))
        drawCircle(color = Color(0xFF00FF00).copy(alpha = 0.3f), radius = r * 0.66f, style = Stroke(1f))
        drawCircle(color = Color(0xFF00FF00).copy(alpha = 0.1f), radius = r * 0.33f, style = Stroke(1f))

        // Crosshairs
        drawLine(Color(0xFF00FF00).copy(alpha = 0.3f), start = Offset(w/2, h/2 - r), end = Offset(w/2, h/2 + r), strokeWidth = 1f)
        drawLine(Color(0xFF00FF00).copy(alpha = 0.3f), start = Offset(w/2 - r, h/2), end = Offset(w/2 + r, h/2), strokeWidth = 1f)

        drawContext.canvas.save()
        rotate(angle) {
            drawArc(
                brush = Brush.sweepGradient(
                    0f to Color.Transparent,
                    0.8f to Color.Transparent,
                    1.0f to Color(0xFF00FF00).copy(alpha = 0.6f)
                ),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = true,
                topLeft = Offset(center.x - r, center.y - r),
                size = Size(r*2, r*2)
            )
            // Sweep line
            drawLine(Color(0xFF00FF00), start = center, end = Offset(center.x + r, center.y), strokeWidth = 3f)
        }
        drawContext.canvas.restore()
    }
}

@Composable
fun DockModeView(isSpeaking: Boolean, currentCommand: Char) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentAlignment = Alignment.Center
    ) {
        // Squarcle Eyes and Hands
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            val eyeW = 120.dp.toPx()
            val eyeH = if (isSpeaking) 60.dp.toPx() else 120.dp.toPx()
            
            val eyeOffset = if (currentCommand == 'f') -20f else if (currentCommand == 'b') 20f else 0f
            val eyeLX = w / 2 - eyeW - 40f
            val eyeRX = w / 2 + 40f
            
            // Left Eye
            drawRoundRect(
                color = ElectricBlue,
                topLeft = Offset(eyeLX, h / 2 - eyeH / 2 + eyeOffset),
                size = Size(eyeW, eyeH),
                cornerRadius = CornerRadius(40f, 40f)
            )
            // Right Eye
            drawRoundRect(
                color = ElectricBlue,
                topLeft = Offset(eyeRX, h / 2 - eyeH / 2 + eyeOffset),
                size = Size(eyeW, eyeH),
                cornerRadius = CornerRadius(40f, 40f)
            )

            // Robotic Hands
            val handW = 40.dp.toPx()
            val handH = 160.dp.toPx()
            val handOffsetY = if (currentCommand != 's') -40f else 0f
            
            // Left Hand
            drawRoundRect(
                color = TranslucentBlue,
                topLeft = Offset(eyeLX - handW - 40f, h / 2 - handH / 2 + handOffsetY),
                size = Size(handW, handH),
                cornerRadius = CornerRadius(20f, 20f)
            )
            // Right Hand
            drawRoundRect(
                color = TranslucentBlue,
                topLeft = Offset(eyeRX + eyeW + 40f, h / 2 - handH / 2 + handOffsetY),
                size = Size(handW, handH),
                cornerRadius = CornerRadius(20f, 20f)
            )
        }
    }
}
