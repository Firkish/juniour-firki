package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBlack = Color(0xFF050505)
val ElectricBlue = Color(0xFF00E5FF)
val ElectricBlueDim = Color(0x3300E5FF)
val DarkGray = Color(0xFF1A1A1A)
val MediumGray = Color(0xFF333333)
val TranslucentBlue = Color(0x4000E5FF)
val TranslucentGray = Color(0x40333333)
val SoftWhite = Color(0xFFE0E0E0)
val DangerRed = Color(0xFFFF3B30)
val WarningYellow = Color(0xFFFFCC00)
val SuccessGreen = Color(0xFF34C759)
